<?php
  require 'class/class.phpmailer.php';
    $mail = new PHPMailer;
    $email = $_POST['email'];
    $name = $_POST['name'];
    $message = $_POST['message'];
            
      $mail->IsSMTP();
      $mail->Host = "smtp.gmail.com";

      $mail->SMTPAuth = true;
      $mail->SMTPSecure = "ssl";
      $mail->Port = 465;
      $mail->Username = "jamshaidiqbal120@gmail.com"; //add your gmail
      $mail->Password = "Jamoodgreat120@";


       //Sets connection prefix. Options are "", "ssl" or "tls"
       $mail->From ="jamshaidiqbal120@gmail.com" ; //add your email    //Sets the From email address for the message
       $mail->FromName ='Orpho Care';    //Sets the From name of the message
    //  $mail->setFrom($_POST["email1"], $_POST["name"]);//contact show
      
      $mail->AddAddress($email);     //Add your email address 
 
      //$mail->AddAddress('farahjabeen.2021@gmail.com',/*dealername*/);//Adds a "To" address
      $mail->AddCC($email); //Adds a "Cc" address
      $mail->WordWrap = 50;       //Sets word wrapping on the body of the message to a given number of characters
      $mail->IsHTML(true);       //Sets message type to HTML    
      $mail->Subject = "Thanks For Contacting";    //Sets the Subject of the message
      $mail->Body = 'This was your message';    //An HTML or plain text message body
  if($mail->Send())        //Send an Email. Return true on success or false on error
  {
    echo "Failed";
header('Location:orphomain.html');  }
  else
  {
    echo 'Success';


  }
  
?>