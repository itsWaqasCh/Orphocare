<footer class="blog-footer p-4" style="text-align:center;color:white;">
  <p>&copy; <?php echo date("Y"); ?> Tailor Master ( Design By Umair)</p>
</footer>
</body>
</html>