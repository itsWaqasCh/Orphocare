<?php
$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "orphocare";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
if(isset($_POST['insert'])){
$id =$_POST['id'];
$name =$_POST['name'];
$contact =$_POST['contact'];
$donationtype =$_POST['dtype'];
$amount =$_POST['amount'];
$city =$_POST['city'];
   

$sql = "INSERT INTO donors
VALUES ('$id', '$name', '$contact','$donationtype', '$amount', '$city');";

if ($conn->multi_query($sql) === TRUE) {
    echo "New records created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
$conn->close();
?>