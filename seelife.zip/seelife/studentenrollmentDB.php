<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "orphocare");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$id = mysqli_real_escape_string($link, $_REQUEST['id']);
$name = mysqli_real_escape_string($link, $_REQUEST['name']);
$contact = mysqli_real_escape_string($link, $_REQUEST['fee']);
$dtype = mysqli_real_escape_string($link, $_REQUEST['peducation']);
$amount = mysqli_real_escape_string($link, $_REQUEST['dob']);
$city = mysqli_real_escape_string($link, $_REQUEST['class']);
 
// Attempt insert query execution
$sql = "INSERT INTO students (RollNo,Name, Fee, PreviousEducation, JoiningDate, Class) VALUES ('$id', '$name', '$contact','$dtype', '$amount', '$city')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>