<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="contactformdesign.css ">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

.navbar {
  overflow: hidden;
  background-color: #333;
}

.navbar a {
  float: left;
  font-size: 16px;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.navbar a:hover, .dropdown:hover .dropbtn {
  background-color: red;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>
</head>
<body>

<div class="navbar">
  <div class="navbar-header">
      <a class="navbar-brand" href="#">OrphoCare Health and Food Manager Panel</a>
    </div>
  <div class="dropdown">
    <button class="dropbtn">Doctor Portal 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="adddoctor.php">Add Doctor </a>
      <a href="removedoctor.php">Remove Doctor</a>
      <a href="viewdoctordetails.php">View Doctor Details</a>
    </div>

  </div> 

  <div class="dropdown">
    <button class="dropbtn">Chef Portal
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addchief.php">Add Chef</a>
      <a href="removechief.php">Remove Chef</a>
      <a href="viewchiefdetails.php">View Chef Details</a>
    </div>
    </div>
   <div class="dropdown">
    <button class="dropbtn">Food Portal
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addfoodstock.php">Add Food Stock</a>
      <a href="inventory.php">Inventory</a>
          </div>

  </div> 
    <div class="dropdown">
    <button class="dropbtn">Medicine Portal
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="addmedicinedetail.php">Add Medicine Detail</a>
      <a href="inventorys.php">Inventory</a>
          </div>
  



  </div> 


 <div class="dropdown">
    <button class="dropbtn">Food Schedule
      <i class="fa fa-caret-down"></i>
    </button>
   </div>


  <div > 
  <a  href="logout.php">LOGOUT</a>
  </div>
</div>
</div>

<h2 align="center">Add Chef Information</h3>

  <div class="login-page" class="container">
  <div class="form">
   
    </form>
    <form class="login-form" action="addchefDB.php">
      <input type="Number" placeholder="ID" name="id">
      <input type="text" placeholder="Name" name="name">
         <input type="Number" placeholder="Contact" name="contact">
         <input type="text" placeholder="Address" name="address">
       
        
       <select name="post" > 
        <option value="">--Post--</option>
   <option value="MasterChef">Master Chef</option>
  <option value="SeniorChef">Senior Chef</option>
  <option value="JuniorChef">Junior Chef</option>
   
  
</select>
 <input type="date" placeholder="Joining Date" name="jdate">
       <input type="Number" placeholder="Salary" name="salary">
      <button type="submit" name="save">Insert</button>
     
    </form>
  </div>
</div>

</body>
</html>