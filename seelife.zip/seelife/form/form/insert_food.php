<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
  

               
                  
                  $day = $_POST['day'];
                  $breakfast= $_POST['breakfast'];
                  $lunch = $_POST['lunch'];
                  $dinner = $_POST['dinner'];
                  $tea = $_POST['tea'];
                 
          
          
             # code...
             
            $sql = sprintf("INSERT INTO `food`( `day`, `breakfast`, `lunch`, `dinner`, `tea`) VALUES 
             ('$day','$breakfast','$lunch','$dinner','$tea')");
           if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            header("location:add_food_plan.php");

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
            
           // mysqli_close($conn);

    
 ?>
