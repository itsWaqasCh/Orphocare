<?php
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$conn =  new mysqli($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn,'project');

if(! $conn )
{
   die('Could not connect: ' . mysql_error());
}  


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Daily Food Plan</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>


	<div class="container-contact100">
		<div >
			

			<div class="contact100-form-title" style="background-image: url(images/bg-02.jpg);">
				<span>Daily Food Plan</span>
			</div>
<?php 
$query = sprintf("SELECT id as ID,day as Day,breakfast as Breakfast,lunch as Lunch,dinner as Dinner,tea as Tea from food ");
$retval = mysqli_query($conn,$query);

if(! $retval )
{
   die('Could not get data: ' );
}
?>
			<table style="background-color:white;" class="table bordered-tbl">
  <tr>
	  <td>Id</td>
	  <td>Day</td>
	  <td>Breakfast</td>
	  <td>Lunch</td>
	  <td>Dinner</td>
	  <td>Tea</td>

	</tr>
			<?php
   while($row = mysqli_fetch_array($retval))
   {    
  ?> <tr>
  

  <td> <?php echo $row[0]; ?></td>
  <td> <?php echo $row[1]; ?></td>
  <td> <?php echo $row[2]; ?></td>
  <td> <?php echo $row[3]; ?></td>
  <td> <?php echo $row[4]; ?></td>
  <td> <?php echo $row[5]; ?></td>

  <tr>

  <?php } ?>				

			</table>
		</div>
	</div>


	

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'UA-23581568-13');
	</script>
</body>
</html>
