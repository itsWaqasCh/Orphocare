<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
  

               
                  
                  $cnic = $_POST['cnic'];
                  $phone= $_POST['phone'];
                  $address= $_POST['address'];
                 
                 
          
          
             # code...
             
            $sql = sprintf("
            UPDATE `employ` SET 
            `phone`='$phone', address='$address' WHERE cnic='$cnic'
            ");
            

            if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
          header("location:upadte_staff_form.php");

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
            
         

    
 ?>
