<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
  

               
                  
                  $age = $_POST['age'];
                  $phone= $_POST['phone'];
                  $address= $_POST['address'];
                 
                 
          
          
             # code...
             
            $sql = sprintf("
            UPDATE `residents` SET 
            `age`='$age', address='$address' WHERE phone='$phone'
            ");
            

            if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
          header("location:upadte_person_form.php");

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
            
         

    
 ?>
