<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
   $image = $_FILES['image']['tmp_name'];

   $img = file_get_contents($image);

      $name = $_POST['name'];
      $email= $_POST['email'];
      $cnic= $_POST['cnic'];
      $phone = $_POST['phone'];
      $address = $_POST['address'];
      $post = $_POST['post'];
      $gender= $_POST['gender'];
      $password= $_POST['password'];
      $date=date("Y/m/d");
             # code...
             
             $sql = sprintf("INSERT INTO `employ`(`image`,`name`, `email`, `cnic`, `phone`, `address`, `post`, `gender`, `password`, `JoiningDate`) 
             VALUES (?,'$name','$email','$cnic','$phone','$address','$post','$gender','$password','$date')");
  $stmt = mysqli_prepare($conn,$sql);

  mysqli_stmt_bind_param($stmt, "s",$img);
  

  mysqli_stmt_execute($stmt);

  $check = mysqli_stmt_affected_rows($stmt);
          
             if($check==1 )
             {
               echo 'saved';
               header("location:add_staff_form.php");
               
             }else {
               die('Data couldn\'t be saved');
 
             }      
               
              
               
             mysqli_close($conn);

          
          
     
    
 ?>
