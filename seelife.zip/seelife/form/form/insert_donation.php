<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
  

               
                  
                  $name = $_POST['name'];
                  $amount= $_POST['amount'];
                  $type = $_POST['type'];
                  $cnic = $_POST['cnic'];
                  $location = $_POST['location'];
                  $date1= $_POST['date1'];
                 
          
          
             # code...
             
            $sql = sprintf("INSERT INTO `donation`( `name`, `amount`, `type`, `cnic`, `location`,`date`) VALUES 
             ('$name','$amount','$type','$cnic','$location','$date1')");
           echo $sql;
           if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            header("location:add_donation_form.php");

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
            
           // mysqli_close($conn);

    
 ?>
