<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
  

               
                  
                  $day = $_POST['day'];
                  $breakfast= $_POST['breakfast'];
                  $lunch = $_POST['lunch'];
                  $dinner = $_POST['dinner'];
                  $tea = $_POST['tea'];
                 
          
          
             # code...
             
            $sql = sprintf("
            UPDATE `food` SET 
            `breakfast`='$breakfast',`lunch`='$lunch',`dinner`='$dinner',
            `tea`='$tea' WHERE day='$day'
            ");
            

            if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
          header("location:update_food_plan.php");

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
            
         

    
 ?>
