<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
  

               
                  
                  $id1 = $_POST['id1'];
                  $quantity= $_POST['quantity'];
                 
                 
          
          
             # code...
             
            $sql = sprintf("
            UPDATE `medicine` SET 
            `quantity`='$quantity' WHERE id='$id1'
            ");
            

            if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
          header("location:update_medicine_form.php");

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
            
         

    
 ?>
