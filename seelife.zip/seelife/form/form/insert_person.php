<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
   $image = $_FILES['image']['tmp_name'];

   $img = file_get_contents($image);

               
                  
                  $name = $_POST['name1'];
                  $age= $_POST['age'];
                  $phone = $_POST['phone'];
                  $address = $_POST['address'];
                  $gender = $_POST['gender'];

          
          
             # code...
             
            $sql = sprintf("INSERT INTO `residents`(`image`,`name`, `age`, `phone`, `address`, `gender`,`added_by`) 
            VALUES (?,'$name','$age','$phone','$address','$gender',1)");
                
                $stmt = mysqli_prepare($conn,$sql);

                mysqli_stmt_bind_param($stmt, "s",$img);
                
              
                mysqli_stmt_execute($stmt);
              
                $check = mysqli_stmt_affected_rows($stmt);
                        
          //  $retval = mysqli_query(  $conn,$sql );
            
            if( $check!=1 )
            {
               die('Data couldn\'t be saved');
            }else {
                echo 'saved';
                header("location:add_person_form.php");

            }      
            mysqli_close($conn);

    
 ?>
