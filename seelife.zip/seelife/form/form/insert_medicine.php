<?php 
session_start();
   $dbhost = 'localhost';
   $dbuser = 'root';
   $dbpass = '';
   $conn = mysqli_connect($dbhost, $dbuser, $dbpass);
   mysqli_select_db($conn,'project');

   if(! $conn )
   {
      die('Could not connect: ' . mysql_error());
   }
  

               
                  
                  $name = $_POST['name'];
                  $expiry= $_POST['expiry'];
                  $type = $_POST['type'];
                  $quantity=$_POST['quantity'];
          
          
             # code...
             
            $sql = sprintf("INSERT INTO `medicine`(`name`,`type`, `expiry`,`quantity`) 
            VALUES ('$name','$type','$expiry','$quantity')");
             
           if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
            header("location:add_medicine_form.php");

        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
            
            mysqli_close($conn);

    
 ?>
