<?php


session_start();
include("db.php");

if(isset($_SESSION['id'])){
	header("Location: admin.php");

	exit();
}

if(isset($_POST['submit'])){
    $username = mysqli_real_escape_string($con,strtolower($_POST['uname']));
    $password = mysqli_real_escape_string($con,$_POST['psw']);
     $department = mysqli_real_escape_string($con,$_POST['dept']);
	
	if(empty($username) or empty($password)){
		$error = "Empty Username or Password !!!";
	}else{
		
    $check_username_query = "SELECT * FROM employ WHERE id = '$username'";
    $check_username_run = mysqli_query($con,$check_username_query);
    
    if(mysqli_num_rows($check_username_run) > 0){
        $row = mysqli_fetch_array($check_username_run);
        
        $db_username = $row['id'];
        $db_password = $row['passwd'];
         $db_dept = $row['Department'];
        
        
        
        if($username == $db_username && $password == $db_password && $department==$db_dept && $db_dept=="Admin"){
            header('Location: admin.php');
            $_SESSION['username'] = $db_username;
            exit();
        }else if($username == $db_username && $password == $db_password && $department==$db_dept && $db_dept=="Senior Management"){
            header('Location: sm.php');
            $_SESSION['username'] = $db_username;
            exit();

}
else if($username == $db_username && $password == $db_password && $department==$db_dept && $db_dept=="Health and Food Management"){
            header('Location: h&f.php');
            $_SESSION['username'] = $db_username;
            exit();

}
else if($username == $db_username && $password == $db_password && $department==$db_dept && $db_dept=="Cloth and Education Management"){
            header('Location: c&e.php');
            $_SESSION['username'] = $db_username;
            exit();

}

        else{
        $error = "Invalid username or password. Please try again.";    
        }
    }else{
        $error = "Invalid username or password. Please try again.";
    }
	}
}

?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>OrphoCare Login</title>

   
	<link rel="icon" type="image/png" href="image.php">
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    
    
    <link href="floating-labels.css" rel="stylesheet">
    <link href="style1.css" rel="stylesheet">
  </head>



  <body class='login_bg'>
	<?php
		if(isset($_GET['logout_msg'])){
		echo "<script type='text/javascript'>window.onload = function(){ alert('".$_GET['logout_msg']."');}</script>";
		}
		if(isset($error)){
			
			 echo "<script type='text/javascript'>window.onload = function(){ alert('$error !!'); }</script>";
		}
	?>
    <form class="form-signin" action="index.php" method="post" class="container">
  <div class="text-center mb-4 wht_txt" style="color: black">
    <img class="mb-4" src="image.jpg" alt="Logo" width="40%" height="40%" >
    <h1 class="h3 mb-3 font-weight-normal" >LOGIN </h1>
    <p>Please sign in !</p>
  </div>

  <div class="form-label-group">
    <input type="text" id="uname" name="uname" class="form-control" placeholder="Enter Username" required autofocus>
    <label for="uname">Username</label>
  </div>

  <div class="form-label-group">
    <input type="password" id="psw" name="psw" class="form-control" placeholder="Enter Password" required>
    <label for="psw">Password</label>
  </div>
  <div class="form-label-group">
    <select class="form-control" name="dept"> Select 
       <option value="">--Select Department--</option>
        <option value="Admin">Admin</option>
  <option value="Senior Management">Senior Management</option>
  <option value="Health and Food Management">Health and Food Management</option>
  <option value="Cloth and Education Management">Cloth and Education Management</option>
    </select>
  </div>

  <button class="btn btn-lg btn-primary btn-block" style='background:lightblue;color:black;' type="submit" name="submit">Sign in</button>

  <br>
    <a href="orphomain.html"><input class="btn btn-lg btn-primary btn-block" style="background:tomato;color:black;" type="button" name="cancel" Value="Cancel"></a>
</form>
    <br>
	<div class="form-label-group wht_txt">
	<?php  ?>
  </div>
	


</form>

	
</body>
</html>
