<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "root", "", "orphocare");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$id = mysqli_real_escape_string($link, $_REQUEST['donorid']);
$name = mysqli_real_escape_string($link, $_REQUEST['donorname']);
$contact = mysqli_real_escape_string($link, $_REQUEST['contact']);
$dtype = mysqli_real_escape_string($link, $_REQUEST['dtype']);
$amount = mysqli_real_escape_string($link, $_REQUEST['amount']);
$city = mysqli_real_escape_string($link, $_REQUEST['city']);
 
// Attempt insert query execution
$sql = "INSERT INTO donors (Donor_ID,Name, Contact, Donation_Type, Amount, City) VALUES ('$id', '$name', '$contact','$dtype', '$amount', '$city')";
if(mysqli_query($link, $sql)){
    echo "Records added successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>